# How to Install
## Windows
TBA

## Linux
TBA

## Mac
TBA
